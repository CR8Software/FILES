
***************************

CR8tracer 1.1 - Source code

Allan Murray, April 2008.
			
***************************


	   
DESCRIPTION

This is the complete source code for CR8tracer 1.1.
The .gfs conversion routines may be hard to understand without further 
documentation. Potrace output (Potrace State is cubic bezier) is 
converted to 'nodes' data, which contains both cubic and quadratic 
bezier information. Nodes data is then save to a .gfs file 
(quadratic form). 

New to version 1.1 is the option to output .gfs files as PostScript 
(cubic) curves - which are supported by CR8 Type version 2.2 or greater. 
Also new is the option to set default type settings for either
PostScript or TrueType output.
 

COMPILATION

Cr8tracer is written in Pascal - compile with Freepascal 2.0.04.
The Potrace dll in c - compile with MinGW C.
Compile the rc file with windres.


POTRACE LIBRARY

The original Potrace source code is included in the file potrace-1.8.win32-i386.
The only modification that I have made is to the main.c file which is with 
the CR8tracer source. Basically I have wrapped it as a dll, so that I can 
interface with CR8tracer, which is written in Pascal.


COPYRIGHT

 Copyright (C) 2007 - 2008  Allan Murray

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or (at
 your option) any later version.

 This program is distributed in the hope that it will be useful, but
 WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307,
 USA. See also http://www.gnu.org/.

 See the file GNUlicense for details.
 

Allan Murray
CR8 Software Solutions
www.cr8software.net