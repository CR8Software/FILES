/* Weditres generated include file. Do NOT edit */


#define	DLG_OPTIONS		1000
#define	D_ascender		1001
#define	D_Tcolour		1002
#define	D_colour		1003
#define	D_colour_change	1004
#define	d_uppercase		1010
#define	d_lowercase		1011
#define	d_descender		1012
#define	DLG_TOOL		2000
#define	d_top			2003
#define	d_bottom		2004
#define	d_ctop			2005
#define	d_cbottom		2006
#define	d_preview		2007
#define	DLG_TRACE		4000
#define	d_defaults		4010
#define	d_filter		4050
#define	d_turdsize		4051
#define	d_alphamax		4052
#define	d_optitolerance	4053
#define	d_opticurve		4054
#define	d_turnpolicy	4055 
#define	d_spacing		4075 
#define	DLG_ABOUT		3000
#define	d_v20			4076 
#define	d_v21			4077
#define	d_defaultps		4101
#define	d_defaulttt		4102