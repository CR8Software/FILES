#!/bin/bash

echo
echo "====================================="
echo
echo "Installing Type light 3.2x for Linux"
echo
echo "License summary:"
echo "- Commercial use allowed by single-person businesses only"
echo "- cannot modify the program/tar-archive"
echo "- can only redistribute the unmodified tar-archive"
echo "- publisher does not accept liability."
echo "Please read /opt/typelight/Copyright.txt or last page of manual"
echo "for full license terms."
echo

echo "Creating preferences..."
if [ ! -d "/etc/opt/typelight" ]
  then
   mkdir /etc/opt/typelight
fi
cp /opt/typelight/typeconfig.ini /etc/opt/typelight/typeconfig.ini
chmod 666 /etc/opt/typelight/typeconfig.ini 

echo "Creating application shortcut..."
chmod 777 /opt/typelight/bin/Typelight
chmod 777 /opt/typelight/typelight.desktop
cp /opt/typelight/typelight.desktop /usr/share/applications/typelight.desktop


echo "Copying fonts..."
if [ ! -d "/usr/share/fonts/type" ]
  then
   mkdir /usr/share/fonts/type
fi
cp /opt/typelight/fonts/CR8suppC.ttf /usr/share/fonts/type/CR8suppC.ttf
cp /opt/typelight/fonts/Quivira.ttf /usr/share/fonts/type/Quivira.ttf
cp /opt/typelight/fonts/CharisSIL-R.ttf /usr/share/fonts/type/CharisSIL-R.ttf
cp /opt/typelight/fonts/GalSILR.ttf /usr/share/fonts/type/GalSILR.ttf
cp /opt/typelight/fonts/ScheherazadeRegOT.ttf /usr/share/fonts/type/ScheherazadeRegOT.ttf

echo "Updating font cache... (please wait)"
fc-cache -f /usr/share/fonts/type


echo
echo "Type light 3.2.007x install complete."
echo

