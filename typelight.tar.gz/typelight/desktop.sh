#!/bin/bash

echo "Creating desktop shortcut..."
cp /opt/typelight/typelight.desktop $HOME/Desktop/typelight.desktop

echo
echo "Complete."
echo

