Type 3.2x for Linux install instructions
========================================


With sudo
---------
Change to the directory containing the downloaded tar-archive:
	cd Downloads
 
and enter:
	sudo tar -xzf typelight.tar.gz -C /opt
	sudo /opt/typelight/install.sh

to create a desktop shortcut:
	/opt/typelight/desktop.sh


Without sudo
------------
Change to the directory containing the downloaded tar-archive:
	cd Downloads
 
and enter:
	su
	[password]
	tar -xzf typelight.tar.gz -C /opt
	/opt/typelight/install.sh
	exit

to create a desktop shortcut (exit su first):
	/opt/typelight/desktop.sh

To excute from the command line
-------------------------------
	/opt/typelight/bin/Typelight


CR8 Software Solutions
cr8software.net

